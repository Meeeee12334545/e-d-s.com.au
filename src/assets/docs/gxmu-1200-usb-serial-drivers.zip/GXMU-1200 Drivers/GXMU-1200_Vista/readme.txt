
Release Note, PL-2303 (HX & X) Vista Driver Installer v3.0.1.0, Prolific Edition
==========================================================================
 
System Requirement:
--------------------
. Windows Vista 32/64 bits versions
. USB host controller
. Device using PL-2303 (HX and X version chip only)

NOTE: This Vista driver "DOES NOT" support PL-2303 (chip H version). 


Supported device ID:
---------------------
    VID_067B & PID_2303
 
 

=====================================================
Prolific Technology Inc. 
http://www.prolific.com.tw


